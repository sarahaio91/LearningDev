﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class SampleConfigViewModel
    {
        public bool CanDoA {get;set;}
        public bool CanDoB {get;set;}
        public bool CanDoC {get;set;}
    }

    public class ReactieDomainLayerVM
    {

    }
}